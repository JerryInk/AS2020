﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace AS2020_Dron_Taxi {
    public partial class PersonalInfo : Form {
        AuthForm parentForm;
        NpgsqlConnection pgConnection;
        int user_id;
        String gender_id;
        ArrayList roles_id = new ArrayList();
        ArrayList functions_id = new ArrayList();
        String role_id;
        String role_sys_name;
        String role_name;
        public PersonalInfo(AuthForm parent, NpgsqlConnection conn, int id) {
            parentForm = parent;
            pgConnection = conn;
            user_id = id;
            InitializeComponent();
        }

        private void PersonalInfo_FormClosed(object sender, FormClosedEventArgs e) {
            parentForm.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e) {
            parentForm.Visible = true;
            this.Close();
        }

        private void PersonalInfo_Load(object sender, EventArgs e) {
            NpgsqlDataReader dbReader = null;
            NpgsqlCommand cmdSelect = new NpgsqlCommand("SELECT * FROM personalinfo WHERE id_user = " + user_id, pgConnection);
            try {
                dbReader = cmdSelect.ExecuteReader();
                if (dbReader.HasRows) {
                    while (dbReader.Read()) {
                        tbSecondName.Text = dbReader["secondname"].ToString();
                        tbFirstName.Text = dbReader["firstname"].ToString();
                        tbMiddleName.Text = dbReader["middlename"].ToString();
                        tbBirthDate.Text = dbReader["birthdate"].ToString();
                        tbMail.Text = dbReader["e_mail"].ToString();
                        tbPhone.Text = dbReader["phone"].ToString();
                        gender_id = dbReader["id_gender"].ToString();
                    }
                }
            } catch (Exception ex) {
                MessageBox.Show(this, ex.Message, "Ошибка получения данных о пользователе", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            } finally {
                if (dbReader != null) {
                    dbReader.Close();
                }
            }

            dbReader = null;
            NpgsqlCommand cmdSelectGen = new NpgsqlCommand("SELECT * FROM gender WHERE id = " + gender_id, pgConnection);
            try {
                dbReader = cmdSelectGen.ExecuteReader();
                if (dbReader.HasRows) {
                    while (dbReader.Read()) {
                        tbGender.Text = dbReader["name"].ToString();
                    }
                }
            } catch (Exception ex) {
                MessageBox.Show(this, ex.Message, "Ошибка получения данных о пользователе", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            } finally {
                if (dbReader != null) {
                    dbReader.Close();
                }
            }

            dbReader = null;
            NpgsqlCommand cmdSelectRole = new NpgsqlCommand("SELECT * FROM userroles " + 
                                                            "JOIN role ON role.id = userroles.id_role WHERE id_user = " 
                                                            + user_id, pgConnection);
            try {
                dbReader = cmdSelectRole.ExecuteReader();
                if (dbReader.HasRows) {
                    while (dbReader.Read()) {
                        ListViewItem itmRoles = lvRoles.Items.Add(Convert.ToString(dbReader["name"]));
                        roles_id.Add(Convert.ToString(dbReader["id_role"]));
                    }
                }
            } catch (Exception ex) {
                MessageBox.Show(this, ex.Message, "Ошибка получения данных о ролях", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            } finally {
                if (dbReader != null) {
                    dbReader.Close();
                }
            }
        }

        private void button5_Click(object sender, EventArgs e) {
            ////
        }

        private void button1_Click(object sender, EventArgs e) {
            ////
        }

        private void button2_Click(object sender, EventArgs e) {
            ////
        }

        private void button3_Click(object sender, EventArgs e) {
            ////
        }

        private void lvRoles_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e) {
            int index = 0;
            index = e.ItemIndex;
            role_id = roles_id[index].ToString();
            lvFunctions.Clear();
            NpgsqlDataReader dbReader = null;
            NpgsqlCommand cmdSelectFunc = new NpgsqlCommand("SELECT r.systemname AS r_systemname, r.name AS r_name, rf.id_role AS rf_id_role, rf.id_function AS rf_id_function, sf.systemname AS sf_systemname, sf.name AS sf_name FROM role r JOIN rolefunctions rf ON r.id = rf.id_role JOIN systemfunction sf ON rf.id_function = sf.id WHERE id_role = " + role_id, pgConnection);
            try {
                dbReader = cmdSelectFunc.ExecuteReader();
                if (dbReader.HasRows) {
                    while (dbReader.Read()) {
                        role_sys_name = dbReader["r_systemname"].ToString();
                        role_name = dbReader["r_name"].ToString();
                        ListViewItem itmFuncs = lvFunctions.Items.Add(Convert.ToString(dbReader["sf_name"]));
                        functions_id.Add(Convert.ToString(dbReader["rf_id_function"]));
                    }
                }
            } catch (Exception ex) {
                MessageBox.Show(this, ex.Message, "Ошибка получения данных о функциях", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            } finally {
                if (dbReader != null) {
                    dbReader.Close();
                }
            }

            tbSysName.Text = role_sys_name;
            tbName.Text = role_name;
            label11.Text = "Роль: " + role_name;
        }
    }
}
