﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace AS2020_Dron_Taxi {
    public partial class AuthForm : Form {
        NpgsqlConnection pgConnection;
        public AuthForm() {
            InitializeComponent();
        }

        private void btnEnter_Click(object sender, EventArgs e) {
            NpgsqlParameter pgParam;
            int retVal;
            this.Visible = false;
            try {
                pgConnection = new NpgsqlConnection();
                pgConnection.ConnectionString = Properties.Settings.Default.atom_skills_2020_ConnectionString;
                
                pgConnection.Open();
            } catch (Exception ex) {
                MessageBox.Show(this, ex.Message, "Ошибка подключения к БД", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            // проверка пользователя
            try {
                NpgsqlCommand pgComm = new NpgsqlCommand("dt_user_auth", pgConnection);
                pgComm.CommandType = CommandType.StoredProcedure;
                pgParam = new NpgsqlParameter("@Result", NpgsqlTypes.NpgsqlDbType.Integer);
                pgParam.DbType = DbType.Int32;
                pgParam.Direction = ParameterDirection.ReturnValue;
                pgComm.Parameters.Add(pgParam);
                // добавляем параметры
                pgComm.Parameters.Add("@user_login", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tbLogin.Text;
                pgComm.Parameters.Add("@user_password", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tbPassword.Text;
                // вызываем функцию
                retVal = (int)pgComm.ExecuteScalar();
            } catch (Exception ex) {
                MessageBox.Show(this, ex.Message, "Ошибка авторизации", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Visible = true;
                return;
            }
            if (retVal == -1 || retVal == -2) {
                MessageBox.Show(this, "Неверно указан логин или пароль.", "Ошибка авторизации", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Visible = true;
                return;
            } else {
                PersonalInfo pi = new PersonalInfo(this, pgConnection, retVal);
                tbLogin.Text = "";
                tbPassword.Text = "";
                pi.ShowDialog();
            }
        }

        private void AuthForm_FormClosed(object sender, FormClosedEventArgs e) {
            if (pgConnection != null && pgConnection.State != ConnectionState.Closed) {
                pgConnection.Close();
            }
        }
    }
}
